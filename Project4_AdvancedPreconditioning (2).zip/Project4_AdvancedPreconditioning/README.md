# RAS-Preconditioner

Course project for MAP7386, Numerical Solutions of PDE, Spring 2021 @ UCF (Dr. Borges)

Group:
- Justin Gosselin
- Corey Prachniak
- Kurtis Doobay 
